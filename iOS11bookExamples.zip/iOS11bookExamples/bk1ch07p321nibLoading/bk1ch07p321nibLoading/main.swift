

import UIKit

UIApplicationMain(
    // Process.argc, Process.unsafeArgv, nil, NSStringFromClass(AppDelegate)
    Process.argc, nil, nil, NSStringFromClass(AppDelegate)
)


