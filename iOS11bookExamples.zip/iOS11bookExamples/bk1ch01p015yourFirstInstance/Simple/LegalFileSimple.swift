
import UIKit
var one = 1
func changeOne() {
    let two = 2
    one = two
}
class Manny {
    let name = "manny"
    func sayName() {
        print(name)
    }
}
struct Moe {
}
enum Jack {
}

