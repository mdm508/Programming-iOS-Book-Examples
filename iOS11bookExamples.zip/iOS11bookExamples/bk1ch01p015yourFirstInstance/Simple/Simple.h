//
//  Simple.h
//  Simple
//
//  Created by Matt Neuburg on 4/23/16.
//  Copyright © 2016 Matt Neuburg. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Simple.
FOUNDATION_EXPORT double SimpleVersionNumber;

//! Project version string for Simple.
FOUNDATION_EXPORT const unsigned char SimpleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Simple/PublicHeader.h>


