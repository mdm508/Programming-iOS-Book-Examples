
import UIKit

public class Warthog {
    public init() {} // initializer must be public or main code can't make one
}

open class Owl {
    open var name = "Olly"
}

public struct Eagle {
    
}

class Zebra {
    
}
