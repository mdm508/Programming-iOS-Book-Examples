

#import <Foundation/Foundation.h>

@interface Thing : NSObject
- (void) testThrower;
@end
