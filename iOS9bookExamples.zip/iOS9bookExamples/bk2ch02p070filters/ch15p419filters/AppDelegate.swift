import UIKit

@UIApplicationMain
class AppDelegate : UIResponder, UIApplicationDelegate {
    var window : UIWindow?
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
//        let arr = CIFilter.filterNamesInCategories(nil)
//        for name in arr {
//            let f = CIFilter(name: name)
//            if f != nil {
//                print(name)
//            }
//        }
        
        return true
    }
}
