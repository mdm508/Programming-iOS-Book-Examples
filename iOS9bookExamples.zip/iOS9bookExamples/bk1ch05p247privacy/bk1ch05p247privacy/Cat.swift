
class Cat2 {
    private var secretName : String?
}

