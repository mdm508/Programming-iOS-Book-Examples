
#import <Foundation/Foundation.h>

@interface Pep : NSObject

- (NSArray*) boys;

@end
