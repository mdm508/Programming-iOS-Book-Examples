

#import "Thing.h"

@implementation Pep

- (NSArray*) boys {
    return @[@"Manny", @"Moe", @"Jack"];
}

@end
