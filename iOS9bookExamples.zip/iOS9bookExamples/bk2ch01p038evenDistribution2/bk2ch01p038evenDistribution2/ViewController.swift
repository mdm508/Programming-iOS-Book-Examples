
import UIKit

class ViewController: UIViewController {

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        print("here") // put breakpoint here so we can pause and examine layout
    }

}

