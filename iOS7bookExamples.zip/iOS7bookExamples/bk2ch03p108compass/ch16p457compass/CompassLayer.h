

#import <Foundation/Foundation.h>

@interface CompassLayer : CALayer

@property (nonatomic, strong, readonly) CALayer* arrow;

@end
