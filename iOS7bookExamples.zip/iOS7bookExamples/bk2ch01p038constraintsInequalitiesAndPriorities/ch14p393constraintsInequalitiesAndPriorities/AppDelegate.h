//
//  AppDelegate.h
//  ch14p393constraintsInequalitiesAndPriorities
//
//  Created by Matt Neuburg on 8/1/13.
//  Copyright (c) 2013 Matt Neuburg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
