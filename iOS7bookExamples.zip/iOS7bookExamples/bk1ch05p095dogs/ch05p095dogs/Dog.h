

#import <Foundation/Foundation.h>


@interface Dog : NSObject {
    
}

- (NSString*) speak;
- (NSString*) bark;

@end
