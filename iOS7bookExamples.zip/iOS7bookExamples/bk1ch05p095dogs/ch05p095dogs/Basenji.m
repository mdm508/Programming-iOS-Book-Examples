

#import "Basenji.h"


@implementation Basenji

- (NSString*) bark {
    return @""; // empty string, Basenjis can't bark
}

@end
