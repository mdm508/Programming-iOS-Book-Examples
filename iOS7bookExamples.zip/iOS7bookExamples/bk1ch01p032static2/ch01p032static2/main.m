//
//  main.m
//  ch01p032static2
//
//  Created by Matt Neuburg on 6/26/13.
//  Copyright (c) 2013 Matt Neuburg. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
