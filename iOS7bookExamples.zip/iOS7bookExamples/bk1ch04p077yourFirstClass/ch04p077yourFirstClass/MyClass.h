

#import <Foundation/Foundation.h>


@interface MyClass : NSObject {
    
}
- (NSString*) sayGoodnightGracie;

@end
