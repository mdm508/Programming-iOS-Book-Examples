
#import <UIKit/UIKit.h>

@interface MyView3 : UIView

@end
