

#import <Foundation/Foundation.h>

@interface MyView1 : UIView

@end
