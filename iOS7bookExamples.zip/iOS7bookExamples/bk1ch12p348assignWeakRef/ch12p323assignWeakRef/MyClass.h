

#import <Foundation/Foundation.h>

@interface MyClass : NSObject

@property (nonatomic, weak) id delegate;


@end
