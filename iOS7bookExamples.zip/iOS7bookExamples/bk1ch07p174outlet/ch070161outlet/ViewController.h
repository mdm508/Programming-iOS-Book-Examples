

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property IBOutlet UIButton* button;

@end
