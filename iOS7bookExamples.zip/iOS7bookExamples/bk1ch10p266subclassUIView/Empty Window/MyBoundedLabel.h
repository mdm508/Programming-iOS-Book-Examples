

#import <UIKit/UIKit.h>

@interface MyBoundedLabel : UILabel

@end
