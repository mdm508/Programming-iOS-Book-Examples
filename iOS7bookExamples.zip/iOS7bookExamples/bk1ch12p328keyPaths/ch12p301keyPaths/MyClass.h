

#import <Foundation/Foundation.h>

@interface MyClass : NSObject

@end
