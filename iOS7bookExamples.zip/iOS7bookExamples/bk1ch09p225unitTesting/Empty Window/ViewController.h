

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (NSString*) dogMyCats: (NSString*) cats;
@end
