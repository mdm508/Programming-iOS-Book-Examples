

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (NSString*) dogMyCats: (NSString*) cats {
//    return @"dogs"; // uncomment to pass test
    return nil;
}

@end
