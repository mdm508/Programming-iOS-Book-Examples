

#import <Foundation/Foundation.h>

@interface MyWindow : UIWindow

@end
