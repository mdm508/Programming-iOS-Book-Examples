
#import "MyRedButton.h"

@implementation MyRedButton

- (void) awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor = [UIColor redColor];
}


@end
