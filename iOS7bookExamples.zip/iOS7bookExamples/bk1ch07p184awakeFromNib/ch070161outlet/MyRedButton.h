

#import <UIKit/UIKit.h>

@interface MyRedButton : UIButton

@end
