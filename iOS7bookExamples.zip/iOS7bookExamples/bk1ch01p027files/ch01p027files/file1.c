

#include "file1.h"

// function definitions go here

int square(int i) {
    return i * i;
}