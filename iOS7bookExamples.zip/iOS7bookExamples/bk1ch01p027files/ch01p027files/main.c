

#include <stdio.h>

#include "file2.h" // so we can call doYourThing

int main (int argc, const char * argv[])
{
    doYourThing();
    
    return 0;
}

