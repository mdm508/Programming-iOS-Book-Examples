
#import <Foundation/Foundation.h>

@interface Smiler : NSObject

@end
