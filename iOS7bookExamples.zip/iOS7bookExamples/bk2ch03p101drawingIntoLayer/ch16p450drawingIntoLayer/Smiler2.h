

#import <Foundation/Foundation.h>

@interface Smiler2 : NSObject

@end
