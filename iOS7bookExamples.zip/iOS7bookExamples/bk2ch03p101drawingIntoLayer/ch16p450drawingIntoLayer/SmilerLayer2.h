


@interface SmilerLayer2 : CALayer

@end
