


@interface SmilerLayer : CALayer

@end
